Yo thanks for buying my gen!

Dm me for any questions related to the gen or any bugs you encounter.

YOU WILL NEED TO INSTALL PYTHON FOR THE GEN TO WORK.

How to launch.
1) Go to the folder where main.py is located.
2) go to the top where it says the file location and type "cmd" instead of the text written
3) command promt will launch, type "py main.py" - this is to launch the gen!
4) if it says "module ??? was not found" type in "pip install" + the module name
5) enjoy ;)